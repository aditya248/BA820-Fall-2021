# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %% [markdown]
# # Assignment-1: Hooli Message forum Clustering.
# ## Aditya Sinha
# %% [markdown]
# ## Install & Import Pacakges

# %%
# !pip install wordcloud nltk

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# for distance and h-clustering
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster, cophenet
from scipy.spatial.distance import pdist, squareform
from sklearn.preprocessing import StandardScaler

# sklearn KMeans
from sklearn.cluster import KMeans, DBSCAN
from sklearn.neighbors import NearestNeighbors
from sklearn import metrics 
from sklearn.decomposition import PCA
from matplotlib.pyplot import figure

import nltk
nltk.download('stopwords')
nltk.download('punkt')

import regex as re
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from wordcloud import WordCloud

import plotly.graph_objects as go
import scikitplot as skplt


# %%
# Import the forums dataset.
forums = pd.read_pickle("forums.pkl")
forums.head(3)


# %%
# number of columns
len(forums.columns)

# %% [markdown]
# ## Data Cleaning, and Preprocessing

# %%
# Check to see if there is any identicle column
for x in forums:
    for y in forums:
        if(forums[x].equals(forums[y]) and x!=y):
            print(x,y)
    


# %%
for col in forums.columns.values.tolist():
  if(forums[col].dtypes == "object"):
    forums[col] = forums[col].str.strip()

# replace field that's entirely space (or empty) with NaN
forums = forums.replace('', np.nan)  


# %%
forums.shape


# %%
# Check for duplicates
forums.duplicated().sum()


# %%
forums.drop_duplicates(inplace=True)


# %%
# Check for null values
forums.isna().sum()
forums.isna().sum().sum()


# %%
forums.dropna(inplace=True)


# %%
forums.head(3)


# %%
forums.dtypes


# %%
forums.describe().T

# %% [markdown]
# ### Clean and Tokenize text field

# %%
stops = set(stopwords.words("english"))


# %%
def clean_content(text):
    #Converting text to lowercase characters
    text = text.lower()
    #Removing HTML tags
    text = re.sub(r'\<[^<>]*\>','', text) 
    #Removing any character which does not match to letter,digit or underscore
    text = re.sub(r'^\W+|\W+$',' ', text)
    #Removing space,newline,tab
    text = re.sub(r'\s',' ',text)
    #Removing punctuation
    text = re.sub(r'[^a-zA-Z0-9]',' ',text)
    # Remove any numbers
    text = re.sub(r'[0-9]+', '', text)
    #Tokenizing data
    text = word_tokenize(text)
    #Removing stopwords
    text = [i for i in text if i not in stops]
    return(text)


# %%
forums['text'] = forums['text'].apply(lambda x: clean_content(x))


# %%
frms = forums.copy()
frms = frms.set_index("text")


# %%
frms.head(2)


# %%
frms.shape

# %% [markdown]
# ## Dimensionality Reduction

# %%
# Heatmap to see correlation
sns.set(rc={'figure.figsize':(11.7,8.27)})
frm_corr = frms.corr()
sns.heatmap(frm_corr, cmap="Reds", center=0)


# %%
# PCA
pca = PCA()
pcs = pca.fit_transform(frms)
var_exp_ratio = pca.explained_variance_ratio_


# %%
figure(figsize=(8, 6), dpi=80)
plt.title("Explained Variance Ratio by Component")
plt.xlabel('Number of components')
plt.ylabel('Explained Variance Ratio')
sns.lineplot(range(1,len(pca.explained_variance_ratio_)+1), pca.explained_variance_ratio_)
plt.show()


# %%
fig = go.Figure(data=go.Scatter(x=list(range(1,len(var_exp_ratio)+1)), y=np.cumsum(var_exp_ratio)))
fig.update_layout(
    title="Cum. Explained Variance Ratio by Component",
    xaxis_title="Cum. Explained Variance Ratio",
    yaxis_title="Number of components",
)
fig.show()


# %%
comp_frms = pcs[:,:30]
comp_frms.shape


# %%
frms_pca = pd.DataFrame(comp_frms, columns=["c"+str(x)for x in range(1,31)], index=frms.index)
frms_pca.sample(2)

# %% [markdown]
# ## Hierarchical clustering

# %%
plt.figure(figsize=(20,20))

method = ['complete', 'single', 'ward']
metric = ['euclidean', 'cityblock', 'cosine']
linkage_dict = {}

ind = 0
for i,mtd in enumerate(method):
    for j,met,  in enumerate(metric):
        d0=pdist(frms_pca, metric=met)
        ind = ind+1
        link = linkage(d0,method=mtd)
        linkage_dict[mtd +" - " +met] = link
        plt.subplot(3,3, ind)
        plt.title(mtd +" - " +met)
        dendrogram(link)
  
plt.show()    


# %%
corr = {}
for key,val in linkage_dict.items():
    cop = cophenet(linkage_dict[key])
    corr[key] = np.corrcoef(d0, cop)[0,1]
    
corr    


# %%
bar_plot = sns.barplot(list(corr.keys()),list(corr.values()))
plt.xticks(rotation=90)
plt.show()


# %%
silhouette_her = []
for i in range(2,10):
    hc_labs = fcluster(linkage_dict["ward - euclidean"], i, criterion="maxclust")
    silhouette_her.append(metrics.silhouette_score(frms_pca, hc_labs))


# %%
plt.title('The Silhouette Method')
plt.xlabel('Average Silhouette Width')
plt.ylabel('Silhouette')
plt.axvline(x=4, c='red', lw=3, linestyle='dashed')
plt.axvline(x=3, c='yellow', lw=4, linestyle='dashed')
sns.lineplot(range(2,10),silhouette_her)


# %%
hc_labs_3 = fcluster(linkage_dict["ward - euclidean"], 3, criterion="maxclust")
forums['hie_cluster_3'] = hc_labs_3


# %%
hc_labs_4 = fcluster(linkage_dict["ward - euclidean"], 4, criterion="maxclust")
forums['hie_cluster_4'] = hc_labs_4


# %%
d0=pdist(frms_pca, metric="euclidean")
link = linkage(d0,method="ward")
plt.title("Dendrogram - (Ward-Euclidean)")
dendrogram(link)
plt.axhline(y=14, c='red', lw=2, linestyle='dashed')
plt.axhline(y=16, c='yellow', lw=2, linestyle='dashed')
plt.show()

# %% [markdown]
# ## K-Mean Clustering

# %%
inertia = []
silhouette = []
for i in range(2,10):
    kmeans = KMeans(i, random_state=0)
    kmeans.fit(frms_pca)
    kmeans_lab = kmeans.predict(frms_pca)
    inertia.append(kmeans.inertia_)
    silhouette.append(metrics.silhouette_score(frms_pca, kmeans_lab))


# %%
plt.figure(figsize=(15,5))


plt.subplot(1, 2, 1)
plt.title("Inertia")
sns.lineplot(range(2,10), inertia)

plt.subplot(1, 2, 2)
plt.title("Silohouette Score")
sns.lineplot(range(2,10), silhouette)

plt.show()


# %%
k3 = KMeans(3, random_state=0)
k3.fit(frms_pca)
k3_labs = k3.predict(frms_pca)
forums["kmean_cluster_3"] = k3_labs


# %%
k4 = KMeans(4, random_state=0)
k4.fit(frms_pca)
k4_labs = k4.predict(frms_pca)
forums["kmean_cluster_4"] = k4_labs


# %%
frm_cluster = forums[["hie_cluster_3", "hie_cluster_4", "kmean_cluster_3", "kmean_cluster_4"]]
counts = frm_cluster.apply(pd.value_counts)
counts


# %%
print(forums['hie_cluster_3'].value_counts(normalize=True) * 100)
print(forums['hie_cluster_4'].value_counts(normalize=True) * 100)
print(forums['kmean_cluster_3'].value_counts(normalize=True) * 100)
print(forums['kmean_cluster_4'].value_counts(normalize=True) * 100)


# %%
sns.heatmap(counts, annot=True, fmt='g')


# %%
skplt.metrics.plot_silhouette(frms_pca, k3_labs, figsize=(7,7), title="Silhouette Analysis 3 K-Mean Cluster")


# %%
skplt.metrics.plot_silhouette(frms_pca, k4_labs, figsize=(7,7), title="Silhouette Analysis 4 K-Mean Cluster")


# %%
skplt.metrics.plot_silhouette(frms_pca, hc_labs_3, figsize=(7,7),  title="Silhouette Analysis 3 Hierarchical Cluster")


# %%
skplt.metrics.plot_silhouette(frms_pca, hc_labs_4, figsize=(7,7), title="Silhouette Analysis 4 Hierarchical Cluster")

# %% [markdown]
# ## Analysis and Conclusion

# %%
forums.sample(3)

# %% [markdown]
# ### hie_cluster_3

# %%
grouped_df_hie_3 = forums.copy()
grouped_df_hie_3 = grouped_df_hie_3.groupby('hie_cluster_3').agg({'text': 'sum'}).reset_index()


# %%
grouped_df_hie_3.head()


# %%
from collections import Counter

for i in range(len(grouped_df_hie_3)):
    print(grouped_df_hie_3['hie_cluster_3'][i])
    words = grouped_df_hie_3['text'][i]
    most_common_words= [word for word, word_count in Counter(words).most_common(100)]
    print(most_common_words)
    
    


# %%
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=[14, 14], facecolor = None)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc1 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc1.generate(" ".join(grouped_df_hie_3['text'][0]))

ax1.axis("off")
ax1.imshow(wc1, interpolation="bilinear")
ax1.set_title('Cluster-1',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc2 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc2.generate(" ".join(grouped_df_hie_3['text'][1]))

ax2.axis("off")
ax2.imshow(wc2, interpolation="bilinear")
ax2.set_title('Cluster-2',fontsize=20);

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc3 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc3.generate(" ".join(grouped_df_hie_3['text'][2]))

ax3.axis("off")
ax3.imshow(wc3, interpolation="bilinear")
ax3.set_title('Cluster-3',fontsize=20)

plt.show()

# %% [markdown]
# ### hie_cluster_4

# %%
grouped_df_hie_4 = forums.copy()
grouped_df_hie_4 = grouped_df_hie_4.groupby('hie_cluster_4').agg({'text': 'sum'}).reset_index()


# %%
from collections import Counter

for i in range(len(grouped_df_hie_4)):
    print(grouped_df_hie_4['hie_cluster_4'][i])
    words = grouped_df_hie_4['text'][i]
    most_common_words= [word for word, word_count in Counter(words).most_common(100)]
    print(most_common_words)


# %%
fig, (ax1, ax2, ax3, ax4) = plt.subplots(1, 4, figsize=[14, 14], facecolor = None)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc1 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc1.generate(" ".join(grouped_df_hie_4['text'][0]))

ax1.axis("off")
ax1.imshow(wc1, interpolation="bilinear")
ax1.set_title('Cluster-1',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc2 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc2.generate(" ".join(grouped_df_hie_4['text'][1]))

ax2.axis("off")
ax2.imshow(wc2, interpolation="bilinear")
ax2.set_title('Cluster-2',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc3 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc3.generate(" ".join(grouped_df_hie_4['text'][2]))

ax3.axis("off")
ax3.imshow(wc3, interpolation="bilinear")
ax3.set_title('Cluster-3',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc3 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc3.generate(" ".join(grouped_df_hie_4['text'][3]))

ax4.axis("off")
ax4.imshow(wc3, interpolation="bilinear")
ax4.set_title('Cluster-4',fontsize=20)

plt.show()

# %% [markdown]
# ### K_Mean_3

# %%
grouped_df_k_mean_3 = forums.copy()
grouped_df_k_mean_3 = grouped_df_k_mean_3.groupby('kmean_cluster_3').agg({'text': 'sum'}).reset_index()


# %%
for i in range(len(grouped_df_k_mean_3)):
    print(grouped_df_k_mean_3['kmean_cluster_3'][i])
    words = grouped_df_k_mean_3['text'][i]
    most_common_words= [word for word, word_count in Counter(words).most_common(100)]
    print(most_common_words)


# %%
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=[14, 14], facecolor = None)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc1 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc1.generate(" ".join(grouped_df_k_mean_3['text'][0]))

ax1.axis("off")
ax1.imshow(wc1, interpolation="bilinear")
ax1.set_title('Cluster-1',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc2 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc2.generate(" ".join(grouped_df_k_mean_3['text'][1]))

ax2.axis("off")
ax2.imshow(wc2, interpolation="bilinear")
ax2.set_title('Cluster-2',fontsize=20);

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc3 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc3.generate(" ".join(grouped_df_k_mean_3['text'][2]))

ax3.axis("off")
ax3.imshow(wc3, interpolation="bilinear")
ax3.set_title('Cluster-3',fontsize=20)

plt.show()

# %% [markdown]
# ### K_Mean_4

# %%
grouped_df_k_mean_4 = forums.copy()
grouped_df_k_mean_4 = grouped_df_k_mean_4.groupby('kmean_cluster_4').agg({'text': 'sum'}).reset_index()


# %%
for i in range(len(grouped_df_k_mean_4)):
    print(grouped_df_k_mean_4['kmean_cluster_4'][i])
    words = grouped_df_k_mean_4['text'][i]
    most_common_words= [word for word, word_count in Counter(words).most_common(100)]
    print(most_common_words)


# %%
fig, (ax1, ax2, ax3, ax4) = plt.subplots(1, 4, figsize=[14, 14], facecolor = None)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc1 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc1.generate(" ".join(grouped_df_k_mean_4['text'][0]))

ax1.axis("off")
ax1.imshow(wc1, interpolation="bilinear")
ax1.set_title('Cluster-1',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc2 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc2.generate(" ".join(grouped_df_k_mean_4['text'][1]))

ax2.axis("off")
ax2.imshow(wc2, interpolation="bilinear")
ax2.set_title('Cluster-2',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc3 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc3.generate(" ".join(grouped_df_k_mean_4['text'][2]))

ax3.axis("off")
ax3.imshow(wc3, interpolation="bilinear")
ax3.set_title('Cluster-3',fontsize=20)

x, y = np.ogrid[:300, :300]
mask = (x - 150) ** 2 + (y - 150) ** 2 > 130 ** 2
mask = 255 * mask.astype(int)

wc3 = WordCloud(width = 800, height = 800,background_color="white",min_font_size = 10,    repeat=True, mask=mask)
wc3.generate(" ".join(grouped_df_k_mean_4['text'][3]))

ax4.axis("off")
ax4.imshow(wc3, interpolation="bilinear")
ax4.set_title('Cluster-4',fontsize=20)

plt.show()


